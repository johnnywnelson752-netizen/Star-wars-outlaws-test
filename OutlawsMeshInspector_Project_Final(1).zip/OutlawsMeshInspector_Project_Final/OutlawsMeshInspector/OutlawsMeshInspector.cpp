// OutlawsMeshInspector.cpp
// Minimal working version � hooks xefgSwapChainSetPresentId from libxess_fg.dll
// Requires MinHook (include the headers + add the .cpp files)

#include <Windows.h>
#include <cstdio>
#include "MinHook.h"

// Simple logger
static void DebugLog(const char* fmt, ...)
{
    char buffer[1024];

    va_list args;
    va_start(args, fmt);
    _vsnprintf_s(buffer, sizeof(buffer), _TRUNCATE, fmt, args);
    va_end(args);

    OutputDebugStringA(buffer);
}

// =====================================================================
//  Function pointer type for the real xefgSwapChainSetPresentId()
// =====================================================================

// We do NOT know the real signature.
// The thunk in Outlaws.exe shows it jumps to an imported qword.
// Most XeSS present functions look like:  void func(void* swapChain, int id)
typedef void(__fastcall* tSetPresentId)(void* swapChain, int presentId);

// Original function pointer
tSetPresentId oSetPresentId = nullptr;

// =====================================================================
//  Our Hook
// =====================================================================

void __fastcall SetPresentId_Hook(void* swapChain, int presentId)
{
    DebugLog("[OutlawsMeshInspector] SetPresentId_Hook: swapChain=%p  id=%d\n",
        swapChain, presentId);

    // Call original
    oSetPresentId(swapChain, presentId);
}

// =====================================================================
//  Install Hook
// =====================================================================

void InstallHooks()
{
    DebugLog("[OutlawsMeshInspector] Installing hooks...\n");

    if (MH_Initialize() != MH_OK)
    {
        DebugLog("[OutlawsMeshInspector] MH_Initialize FAILED\n");
        return;
    }

    HMODULE hXeSS = GetModuleHandleA("libxess_fg.dll");
    if (!hXeSS)
    {
        DebugLog("[OutlawsMeshInspector] libxess_fg.dll NOT loaded yet.\n");
        return;
    }

    FARPROC addr = GetProcAddress(hXeSS, "xefgSwapChainSetPresentId");
    if (!addr)
    {
        DebugLog("[OutlawsMeshInspector] Could not find xefgSwapChainSetPresentId\n");
        return;
    }

    DebugLog("[OutlawsMeshInspector] Found xefgSwapChainSetPresentId at %p\n", addr);

    if (MH_CreateHook((LPVOID)addr, &SetPresentId_Hook, (LPVOID*)&oSetPresentId) != MH_OK)
    {
        DebugLog("[OutlawsMeshInspector] MH_CreateHook FAILED\n");
        return;
    }

    if (MH_EnableHook((LPVOID)addr) != MH_OK)
    {
        DebugLog("[OutlawsMeshInspector] MH_EnableHook FAILED\n");
        return;
    }

    DebugLog("[OutlawsMeshInspector] Hook installed successfully.\n");
}

// =====================================================================
//  Remove Hooks
// =====================================================================

void RemoveHooks()
{
    MH_DisableHook(MH_ALL_HOOKS);
    MH_Uninitialize();
    DebugLog("[OutlawsMeshInspector] Hooks removed.\n");
}

// =====================================================================
//  Thread
// =====================================================================

DWORD WINAPI InitThread(LPVOID)
{
    DebugLog("[OutlawsMeshInspector] DLL attached.\n");

    InstallHooks();
    return 0;
}

// ===========================================================
// DllMain � THIS IS WHERE THE MESSAGEBOX BELONGS
// ===========================================================

BOOL APIENTRY DllMain(HMODULE hModule, DWORD reason, LPVOID reserved)
{
    switch (reason)
    {
    case DLL_PROCESS_ATTACH:
        DisableThreadLibraryCalls(hModule);

        // *** POPUP CONFIRMATION ***
        MessageBoxA(
            NULL,
            "OutlawsMeshInspector.dll successfully injected!",
            "OutlawsMeshInspector",
            MB_OK | MB_ICONINFORMATION
        );

        // Start the initialization thread
        CreateThread(nullptr, 0, InitThread, hModule, 0, nullptr);
        break;

    case DLL_PROCESS_DETACH:
        DebugLog("[OutlawsMeshInspector] DLL unloaded.");
        MH_Uninitialize();
        break;
    }

    return TRUE;
}
