OutlawsMeshInspector Visual Studio Project
=========================================

How to open:
1. Open `OutlawsMeshInspector_Project_Final/OutlawsMeshInspector_Project.sln` in Visual Studio 2022.
2. Make sure the active configuration is:
     - Configuration: Debug or Release
     - Platform: x64
3. Build the solution (Build → Build Solution, or Ctrl+Shift+B).

Output:
- DLL will be placed in:
    `OutlawsMeshInspector_Project_Final/bin/Debug/OutlawsMeshInspector.dll`
    or
    `OutlawsMeshInspector_Project_Final/bin/Release/OutlawsMeshInspector.dll`

Injection:
- Copy the built `OutlawsMeshInspector.dll` to your game `Scripts` folder (or wherever your injector expects it).
- Inject the DLL into Outlaws.exe with your preferred injector.
- On success you should see a MessageBox titled "OutlawsMeshInspector".
- Logs are written to: `C:\OutlawsMeshInspector.log`
